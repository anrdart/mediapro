/* global React, ReactDOM,
   Header, Hero, Marquee, About, ServicesIntro, Services, Cta, Stats, Why, Testimonials, Footer,
   useTweaks, TweaksPanel, TweakSection, TweakRadio */

const { useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "mood": "bold",
  "density": "compact",
  "motion": "smooth"
}/*EDITMODE-END*/;

const App = () => {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply mood/density/motion as body classes so CSS can react globally.
  useEffect(() => {
    const cls = document.body.classList;
    // wipe previous
    [...cls].forEach((c) => {
      if (c.startsWith("mood-") || c.startsWith("density-") || c.startsWith("motion-")) cls.remove(c);
    });
    cls.add(`mood-${t.mood}`);
    cls.add(`density-${t.density}`);
    cls.add(`motion-${t.motion}`);
  }, [t.mood, t.density, t.motion]);

  // Load Cormorant Garamond on demand for refined mood
  useEffect(() => {
    if (t.mood === "refined" && !document.getElementById("font-cormorant")) {
      const l = document.createElement("link");
      l.id = "font-cormorant";
      l.rel = "stylesheet";
      l.href = "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400;1,500&display=swap";
      document.head.appendChild(l);
    }
  }, [t.mood]);

  return (
    <React.Fragment>
      <Header />
      <main id="main" role="main">
        <Hero />
        <Marquee />
        <About />
        <ServicesIntro />
        <Services />
        <Cta />
        <Stats />
        <Why />
        <Testimonials />
      </main>
      <Footer />

      <TweaksPanel>
        <TweakSection label="Mood" />
        <TweakRadio
          label="Personality"
          value={t.mood}
          options={["bold", "refined", "punchy"]}
          onChange={(v) => setTweak("mood", v)}
        />

        <TweakSection label="Density" />
        <TweakRadio
          label="Spacing"
          value={t.density}
          options={["airy", "balanced", "compact"]}
          onChange={(v) => setTweak("density", v)}
        />

        <TweakSection label="Motion" />
        <TweakRadio
          label="Animation"
          value={t.motion}
          options={["subtle", "smooth", "lively"]}
          onChange={(v) => setTweak("motion", v)}
        />
      </TweaksPanel>
    </React.Fragment>
  );
};

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
