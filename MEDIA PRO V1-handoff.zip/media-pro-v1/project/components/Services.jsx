/* global React, Icon, Reveal */

const SERVICES = [
  { num: "01", icon: "search",     title: "Search Engine Optimization", desc: "Increase organic traffic, credibility, and long-term visibility." },
  { num: "02", icon: "thumbs-up",  title: "Social Media Marketing",     desc: "Build community, increase engagement, and drive traffic to your offer." },
  { num: "03", icon: "stars",      title: "Content Marketing",          desc: "Educate audiences, build authority, and nurture leads through content." },
  { num: "04", icon: "email",      title: "Email Marketing Campaigns",  desc: "Increase retention, encourage repeat purchases, and convert prospects." },
  { num: "05", icon: "heart",      title: "Influencer Marketing",       desc: "Expand reach, build trust through recommendations, and drive authentic sales." },
  { num: "06", icon: "data",       title: "Analytics & Reporting",      desc: "Measure ROI, identify optimizations, and ensure marketing accountability." },
];

const Services = () => {
  return (
    <section id="services" aria-labelledby="services-heading">
      <div className="container">
        <Reveal>
          <div className="section-head">
            <div>
              <span className="eyebrow">What we offer</span>
              <h2 id="services-heading" className="h-section" style={{marginTop: 18}}>
                Strategic thinkers, creative doers, your marketing leaders.
              </h2>
            </div>
            <p className="right">
              Six disciplines, one team. We pick the right mix for each brand — no templates, no guesswork.
            </p>
          </div>
        </Reveal>

        <Reveal>
          <div className="services-grid" role="list">
            {SERVICES.map((s) => (
              <article className="service-card" key={s.num} role="listitem">
                <span className="num">{s.num} / 06</span>
                <span className="icon-wrap" aria-hidden="true"><Icon name={s.icon} size={26} /></span>
                <h3>{s.title}</h3>
                <p>{s.desc}</p>
              </article>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
};

window.Services = Services;
