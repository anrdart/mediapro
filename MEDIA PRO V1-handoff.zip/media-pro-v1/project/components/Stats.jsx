/* global React */
const { useEffect, useRef, useState } = React;

// Counts from 0 to target when in view. target like "91K+", "84K+", "42+", "4.7"
const parseTarget = (str) => {
  const m = str.match(/^([\d.]+)([KkMm]?)([+]?)$/);
  if (!m) return { value: parseFloat(str) || 0, suffix: "", plus: false, decimals: 0 };
  const value = parseFloat(m[1]);
  const suffix = m[2] || "";
  const plus = m[3] === "+";
  const decimals = (m[1].split(".")[1] || "").length;
  return { value, suffix, plus, decimals };
};

const StatNum = ({ target }) => {
  const { value, suffix, plus, decimals } = parseTarget(target);
  const ref = useRef(null);
  const [n, setN] = useState(0);

  useEffect(() => {
    if (!ref.current) return;
    let raf, started = false;
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting && !started) {
          started = true;
          const start = performance.now();
          const dur = 1600;
          const tick = (t) => {
            const p = Math.min(1, (t - start) / dur);
            // ease out cubic
            const eased = 1 - Math.pow(1 - p, 3);
            setN(value * eased);
            if (p < 1) raf = requestAnimationFrame(tick);
          };
          raf = requestAnimationFrame(tick);
        }
      });
    }, { threshold: 0.4 });
    io.observe(ref.current);
    return () => { io.disconnect(); cancelAnimationFrame(raf); };
  }, [value]);

  return (
    <span className="num" ref={ref}>
      {n.toFixed(decimals)}
      {suffix}
      {plus && <span className="plus">+</span>}
    </span>
  );
};

const STATS = [
  { num: "91K+", label: "Projects Delivered" },
  { num: "84K+", label: "Happy Clients" },
  { num: "42+",  label: "Companies Supported" },
  { num: "4.7",  label: "Client Rating" },
];

const Stats = () => {
  return (
    <section className="stats">
      <div className="container">
        <div className="stats-grid">
          {STATS.map((s) => (
            <div className="stat" key={s.label}>
              <StatNum target={s.num} />
              <span className="label">{s.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

window.Stats = Stats;
