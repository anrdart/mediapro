/* global React */

const TRUSTED_LOGOS = [
  { src: "https://mediapro.work/wp-content/uploads/elementor/thumbs/Untitled-design_11zon-1-scaled-revc4xlhkv3woj6kfsrq5yujum3nifzc3moih9ips0.png", alt: "Yayasan Alfatihah" },
  { src: "https://mediapro.work/wp-content/uploads/elementor/thumbs/Biro-Hukum-warna_11zon-scaled-revc4mbfauogt7my9nw7c1p0pzn8y2qk22uopxzfuo.png", alt: "Biro Hukum" },
  { src: "https://mediapro.work/wp-content/uploads/elementor/thumbs/Logo_11zon-scaled-revc4q2s26tm3nhhnpipm0qv3j4psv5helgmn1tv5s.png", alt: "Rumah Anak Surga" },
  { src: "https://mediapro.work/wp-content/uploads/elementor/thumbs/Logo-1_11zon-scaled-revc4rygfuw6qvercqbyr09saavg89cy2urlllr2tc.png", alt: "Panti Bayi Jogja" },
];

const Marquee = () => {
  // duplicate for seamless loop
  const items = [...TRUSTED_LOGOS, ...TRUSTED_LOGOS, ...TRUSTED_LOGOS];
  return (
    <section className="trusted" aria-label="Trusted brands and organizations">
      <div className="container">
        <p className="trusted-label">Trusted by 25,000+ brands across 40+ countries</p>
      </div>
      <div className="marquee" aria-hidden="true">
        <div className="marquee-track">
          {items.map((logo, i) => (
            <img key={i} src={logo.src} alt={`${logo.alt} — Media Pro client logo`} loading="lazy" />
          ))}
        </div>
      </div>
    </section>
  );
};

window.Marquee = Marquee;
