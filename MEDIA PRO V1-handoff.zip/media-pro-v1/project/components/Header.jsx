/* global React, Icon */
const { useEffect, useState } = React;

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`site-header ${scrolled ? "scrolled" : ""}`} role="banner">
      <div className="nav-inner">
        <a href="#top" className="brand" aria-label="Media Pro — Home">
          <span className="dot" aria-hidden="true"></span>
          MEDIA&nbsp;PRO
        </a>

        <nav aria-label="Primary navigation">
        <ul className={`nav-links ${open ? "open" : ""}`} onClick={() => setOpen(false)}>
          <li><a href="#top">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
        </nav>

        <a href="mailto:mediapro@mediapro.work" className="btn btn-primary nav-cta" aria-label="Get started — email Media Pro">
          Get Started
          <Icon name="arrow-right" size={14} />
        </a>

        <button
          className="menu-btn"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <Icon name="menu" size={20} />
        </button>
      </div>
    </header>
  );
};

window.Header = Header;
