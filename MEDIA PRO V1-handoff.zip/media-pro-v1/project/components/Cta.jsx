/* global React, Reveal */

const Cta = () => {
  return (
    <section className="cta" id="contact">
      <div className="cta-bg-grid"></div>
      <div className="container">
        <Reveal><span className="eyebrow">Let's build something</span></Reveal>
        <Reveal delay={1}>
          <h2 className="h-display" style={{fontSize: "clamp(36px, 5.4vw, 76px)"}}>
            Making your brand <span className="accent">stand out</span> online.
          </h2>
        </Reveal>
        <Reveal delay={2}>
          <p>Your business will become more widely known, recognised, and remembered — to everyone.</p>
        </Reveal>
        <Reveal delay={3}>
          <div style={{display:"flex", gap: 14, justifyContent: "center", flexWrap: "wrap"}}>
            <a href="mailto:mediapro@mediapro.work" className="btn btn-primary">Ask More</a>
            <a href="https://wa.me/6285129992227" target="_blank" rel="noopener" className="btn btn-ghost">WhatsApp us</a>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

window.Cta = Cta;
