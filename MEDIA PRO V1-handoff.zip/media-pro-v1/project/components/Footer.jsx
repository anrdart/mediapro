/* global React, Icon, Reveal */

const Footer = () => {
  return (
    <React.Fragment>
      <section className="footer-cta">
        <div className="container">
          <div>
            <Reveal><span className="eyebrow">Get in touch</span></Reveal>
            <Reveal delay={1}>
              <h2 className="h-display" style={{fontSize: "clamp(36px, 5vw, 72px)"}}>
                Ready to scale? Bring us your <span className="accent">best idea</span>.
              </h2>
            </Reveal>
            <Reveal delay={2}>
              <div style={{display:"flex", gap: 14, flexWrap: "wrap"}}>
                <a href="https://wa.me/6285129992227" target="_blank" rel="noopener" className="btn btn-primary">
                  Get Started
                  <Icon name="arrow-right" size={14} />
                </a>
                <a href="mailto:mediapro@mediapro.work" className="btn btn-ghost">
                  mediapro@mediapro.work
                </a>
              </div>
            </Reveal>
          </div>
          <Reveal delay={2} className="visual">
            <img src="https://mediapro.work/wp-content/uploads/2025/11/img1.png" alt="Grow with Media Pro" />
          </Reveal>
        </div>
      </section>

      <footer className="site-footer">
        <div className="container">
          <div className="footer-grid">
            <div>
              <a href="#top" className="brand">
                <span className="dot"></span>
                MEDIA&nbsp;PRO
              </a>
              <p className="footer-tag">
                A premium digital marketing studio building brands that lead the conversation.
              </p>
            </div>

            <div>
              <h5>Services</h5>
              <ul>
                <li>Web Development</li>
                <li>Google Ads Services</li>
                <li>Meta Ads Services</li>
                <li>Consulting Services</li>
              </ul>
            </div>

            <div>
              <h5>Company</h5>
              <ul>
                <li><a href="terms.html">Terms</a></li>
                <li><a href="disclaimer.html">Disclaimer</a></li>
                <li><a href="faq.html">FAQ</a></li>
                <li><a href="contact.html">Contact</a></li>
              </ul>
            </div>

            <div>
              <h5>Contact</h5>
              <ul>
                <li><a href="mailto:mediapro@mediapro.work">mediapro@mediapro.work</a></li>
                <li><a href="https://wa.me/6285129992227" target="_blank" rel="noopener">WhatsApp · chat now</a></li>
              </ul>
            </div>
          </div>

          <div className="footer-bottom">
            <span>© 2025 Media Pro Creative Limited. All rights reserved.</span>
            <div className="socials">
              <a href="#" aria-label="Instagram"><Icon name="instagram" size={16} /></a>
              <a href="#" aria-label="LinkedIn"><Icon name="linkedin" size={16} /></a>
              <a href="#" aria-label="X / Twitter"><Icon name="x" size={16} /></a>
              <a href="https://wa.me/6285129992227" target="_blank" rel="noopener" aria-label="WhatsApp"><Icon name="whatsapp" size={16} /></a>
            </div>
          </div>
        </div>
      </footer>
    </React.Fragment>
  );
};

window.Footer = Footer;
