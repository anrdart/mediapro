/* global React, Icon, Reveal */

const About = () => {
  return (
    <section id="about" aria-labelledby="about-heading">
      <div className="container">
        <div className="about-grid">
          <div className="about-copy">
            <Reveal><span className="eyebrow">About Media Pro</span></Reveal>
            <Reveal delay={1}>
              <h2 id="about-heading" className="h-section">
                More than a decade of <span style={{color:"var(--gold-dark)", fontStyle:"italic", fontWeight:500}}>digital marketing</span> expertise.
              </h2>
            </Reveal>
            <Reveal delay={2}>
              <p className="lede" style={{marginTop: 24}}>
                We offer a full suite of digital marketing services — SEO, PPC, social media, and content creation — aimed at driving brand visibility and generating significant conversions.
              </p>
            </Reveal>

            <Reveal delay={3} className="about-bullets">
              <div className="bullet">
                <span className="icon-wrap"><Icon name="thumbs-up" /></span>
                <span>Social Media Strategy</span>
              </div>
              <div className="bullet">
                <span className="icon-wrap"><Icon name="cloud" /></span>
                <span>Digital Marketing</span>
              </div>
            </Reveal>

            <Reveal delay={4}>
              <a
                href="https://wa.me/6285129992227"
                target="_blank"
                rel="noopener"
                className="btn btn-primary"
              >
                Contact us
                <Icon name="arrow-right" size={14} />
              </a>
            </Reveal>
          </div>

          <Reveal delay={2} className="about-visual">
            <img src="https://mediapro.work/wp-content/uploads/2025/11/03.png" alt="Media Pro mobile app showcasing digital marketing analytics" width="414" height="600" loading="lazy" />
          </Reveal>
        </div>

        <div className="vmm">
          <Reveal>
            <span className="icon-wrap"><Icon name="rocket" /></span>
            <h4>Our Vision</h4>
            <p>Create a healthy digital marketing ecosystem that lifts every brand we touch.</p>
          </Reveal>
          <Reveal delay={1}>
            <span className="icon-wrap"><Icon name="compass" /></span>
            <h4>Our Mission</h4>
            <p>Stay on the right path of digital marketing — strategic, ethical, and built to last.</p>
          </Reveal>
          <Reveal delay={2}>
            <span className="icon-wrap"><Icon name="handshake" /></span>
            <h4>Our Motto</h4>
            <p>Make your business 10× more visible and valuable than your competitors.</p>
          </Reveal>
        </div>
      </div>
    </section>
  );
};

window.About = About;
