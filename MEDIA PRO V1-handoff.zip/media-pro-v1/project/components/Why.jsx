/* global React, Icon, Reveal */

const REASONS = [
  { icon: "like",       title: "Proven Track Record of Delivering Results", desc: "A documented history of meeting and exceeding ambitious client goals." },
  { icon: "share",      title: "Customized Strategies, Tailored to You",    desc: "Solutions designed around each client's unique audience, budget, and goals." },
  { icon: "briefcase",  title: "Flexible Solutions for Any Business Size",  desc: "Built with scalability in mind — whether you're scrappy or scaling fast." },
  { icon: "chart",      title: "Cost-Effective with a Focus on ROI",        desc: "Every rupiah you invest is engineered to generate maximum measurable value." },
];

const Why = () => {
  return (
    <section>
      <div className="container">
        <Reveal>
          <div className="section-head">
            <div>
              <span className="eyebrow">Why Choose Us</span>
              <h2 className="h-section" style={{marginTop: 18}}>
                The power to transform <span style={{color:"var(--gold)", fontStyle:"italic", fontWeight:500}}>your digital strategy</span>.
              </h2>
            </div>
            <p className="right">
              Four reasons brands stay with us for years — not months.
            </p>
          </div>
        </Reveal>

        <div className="reasons-grid">
          {REASONS.map((r, i) => (
            <Reveal key={r.title} delay={(i % 2) + 1}>
              <div className="reason-card">
                <span className="icon-wrap"><Icon name={r.icon} size={26} /></span>
                <div>
                  <h4>{r.title}</h4>
                  <p>{r.desc}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

window.Why = Why;
