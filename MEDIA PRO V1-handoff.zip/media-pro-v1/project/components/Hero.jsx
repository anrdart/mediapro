/* global React, Icon, Reveal */

const Hero = () => {
  return (
    <section className="hero" id="top" aria-labelledby="hero-heading">
      <div className="container">
        <div className="hero-grid">
          <div className="hero-copy">
            <Reveal><span className="eyebrow">We are Media Pro Creative</span></Reveal>
            <Reveal delay={1}>
              <h1 id="hero-heading" className="h-display">
                Crafting brands that <span className="accent">stand out</span> in a noisy digital world.
              </h1>
            </Reveal>
            <Reveal delay={2}>
              <p className="lede">
                We stay ahead of digital marketing trends so your brand stays sharp, relevant, and impossible to ignore.
              </p>
            </Reveal>
            <Reveal delay={3} className="hero-actions">
              <a href="#about" className="btn btn-primary">
                Discover more
                <Icon name="arrow-right" size={14} />
              </a>
              <a
                href="https://wa.me/6285129992227?text=Hi%2C%20I%27d%20like%20to%20schedule%20a%20free%20consultation"
                target="_blank"
                rel="noopener"
                className="btn btn-ghost"
              >
                Free Consultation
              </a>
            </Reveal>

            <Reveal delay={4} className="hero-meta">
              <div className="m">
                <strong>10+ yrs</strong>
                <span>Industry experience</span>
              </div>
              <div className="m">
                <strong>25K+</strong>
                <span>Global brands trust us</span>
              </div>
              <div className="m">
                <strong>4.7★</strong>
                <span>Client rating</span>
              </div>
            </Reveal>
          </div>

          <Reveal delay={2} className="phone-stage">
            <div className="ring ring-1"></div>
            <div className="ring ring-2"></div>
            <div className="ring ring-3"></div>

            <div className="chip chip-1">
              <Icon name="arrow-up" size={14} />
              <span>Engagement <span className="red">+180%</span></span>
            </div>
            <div className="chip chip-2">
              <Icon name="stars" size={14} />
              <span>Conversion <span className="gold">+45%</span></span>
            </div>
            <div className="chip chip-3">
              <Icon name="people" size={14} />
              <span>Reach <span className="red">2.4M</span></span>
            </div>

            <img
              className="phone"
              src="https://mediapro.work/wp-content/uploads/2025/11/02.png"
              alt="Media Pro digital marketing dashboard preview on mobile"
              width="320"
              height="640"
              loading="eager"
              fetchpriority="high"
            />
          </Reveal>
        </div>
      </div>
    </section>
  );
};

window.Hero = Hero;
