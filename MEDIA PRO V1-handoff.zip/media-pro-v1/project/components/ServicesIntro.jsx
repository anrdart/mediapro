/* global React, Icon, Reveal */

const ServicesIntro = () => {
  return (
    <section>
      <div className="container">
        <div className="services-intro-grid">
          <Reveal className="visual">
            <img src="https://mediapro.work/wp-content/uploads/2025/11/img_3_.png" alt="Strategy in action" />
          </Reveal>

          <div>
            <Reveal><span className="eyebrow">Our Services</span></Reveal>
            <Reveal delay={1}>
              <h2 className="h-section" style={{marginTop: 22}}>
                Innovative strategies, measurable success.
              </h2>
            </Reveal>
            <Reveal delay={2}>
              <p className="lede" style={{marginTop: 22}}>
                Our marketing strategies don't follow the playbook — they rewrite it. So your competitors can't predict your next move.
              </p>
            </Reveal>

            <Reveal delay={3}>
              <div className="highlight-box">
                <span className="icon-wrap"><Icon name="people" /></span>
                <div>
                  <h4>98% client satisfaction with proven results</h4>
                  <p>We work from experience to consistently deliver outcomes that move the needle.</p>
                </div>
              </div>
            </Reveal>

            <Reveal delay={4}>
              <a
                href="https://wa.me/6285129992227"
                target="_blank"
                rel="noopener"
                className="btn btn-primary"
              >
                Free Consultation
                <Icon name="arrow-right" size={14} />
              </a>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
};

window.ServicesIntro = ServicesIntro;
