/* global React, Icon, Reveal */

const TESTIMONIALS = [
  {
    quote: "After working with this team for six months, focusing on SEO and content marketing, our organic traffic skyrocketed 180%. They've helped us compete with the big players — a well-deserved investment.",
    img: "https://mediapro.work/wp-content/uploads/2025/11/WEBDEV_-_MAS_SETYO.webp",
    name: "Setiyo Pramono",
    place: "Marketing Director",
  },
  {
    quote: "They didn't just hand us templates — they truly listened and designed highly efficient Paid Ads and Social campaigns. Our conversion rate jumped 45%.",
    img: "https://mediapro.work/wp-content/uploads/2025/11/Gerin.png",
    name: "Iyus",
    place: "E-commerce Founder",
  },
  {
    quote: "Their expertise across the board — from SEO to SMM — is exceptional. The service is comprehensive and results consistently exceed expectations. Highly recommended.",
    img: "https://mediapro.work/wp-content/uploads/2025/11/WhatsApp-Image-2025-10-20-at-13.44.01_6fec53ab.jpg",
    name: "Suci Rahmawati",
    place: "CMO",
  },
];

const Testimonials = () => {
  return (
    <section>
      <div className="container">
        <Reveal>
          <div className="section-head">
            <div>
              <span className="eyebrow">Client Feedback & Reviews</span>
              <h2 className="h-section" style={{marginTop: 18}}>
                Marketing solutions tailored for your success.
              </h2>
            </div>
          </div>
        </Reveal>

        <div className="growth-stats">
          <Reveal delay={1}>
            <div className="growth-card">
              <span className="icon-wrap"><Icon name="arrow-up" size={26} /></span>
              <div>
                <span className="num">68%</span>
                <h5>Business Growth</h5>
                <p>Many of our clients grow much faster than they planned.</p>
              </div>
            </div>
          </Reveal>
          <Reveal delay={2}>
            <div className="growth-card">
              <span className="icon-wrap"><Icon name="arrow-up" size={26} /></span>
              <div>
                <span className="num">42%</span>
                <h5>Conversion Lift</h5>
                <p>Even small brands see substantial conversion gains.</p>
              </div>
            </div>
          </Reveal>
        </div>

        <div className="testimonials-track">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.name} delay={(i % 3) + 1}>
              <div className="testimonial">
                <p>{t.quote}</p>
                <div className="testimonial-author">
                  <img src={t.img} alt={t.name} />
                  <div>
                    <strong>{t.name}</strong>
                    <span>{t.place}</span>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

window.Testimonials = Testimonials;
