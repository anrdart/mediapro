/* global React */
// Friendly filled-rounded icon set (24x24)
const Icon = ({ name, size = 22 }) => {
  const props = {
    width: size, height: size,
    viewBox: "0 0 24 24",
    fill: "currentColor",
    xmlns: "http://www.w3.org/2000/svg",
    "aria-hidden": "true",
  };
  switch (name) {
    case "thumbs-up":
      return (<svg {...props}><path d="M9 21H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h4v11Zm12-9.4-1.6 7a2 2 0 0 1-2 1.4H11V9.5l3.6-6a1.5 1.5 0 0 1 2.7 1.2L16 9h3.4A2 2 0 0 1 21 11.6Z"/></svg>);
    case "cloud":
      return (<svg {...props}><path d="M17.5 19h-11A4.5 4.5 0 0 1 5 10.1 6 6 0 0 1 17 9a4.5 4.5 0 0 1 .5 10Z"/></svg>);
    case "rocket":
      return (<svg {...props}><path d="M14.5 3a8.5 8.5 0 0 1 6.5 6.5l-7 7-3.2-1L9 12.7l1.7-1.6L8.5 9 7 10.5a3 3 0 0 0 0 4.2l2.4 2.4a3 3 0 0 0 4.2 0L15 15.6 17.3 18l-1.6 1.7-1.4-1.4-7 7L4.6 22l7-7-1-3.2 7-7Z"/><circle cx="14.5" cy="9.5" r="1.5" fill="#0A0A0B"/><path d="M3 21l3-1-2-2-1 3Z"/></svg>);
    case "compass":
      return (<svg {...props}><circle cx="12" cy="12" r="10"/><path d="m15.5 8.5-2 5-5 2 2-5 5-2Z" fill="#0A0A0B"/></svg>);
    case "handshake":
      return (<svg {...props}><path d="m11 7 1 1 4-4 5 5-7 7a2 2 0 0 1-3 0l-3-3a2 2 0 0 1 0-3l3-3Zm-9 6 5-5 2 2-3 3 3 3-2 2-5-5Z"/></svg>);
    case "search":
      return (<svg {...props}><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" fill="none"/></svg>);
    case "stars":
      return (<svg {...props}><path d="m12 3 2.5 5.5L20 10l-5.5 1.5L12 17l-2.5-5.5L4 10l5.5-1.5L12 3Zm7 11 1 2 2 1-2 1-1 2-1-2-2-1 2-1 1-2Z"/></svg>);
    case "email":
      return (<svg {...props}><rect x="2" y="5" width="20" height="14" rx="3"/><path d="m4 7 8 6 8-6" fill="none" stroke="#0A0A0B" strokeWidth="1.6" strokeLinejoin="round"/></svg>);
    case "heart":
      return (<svg {...props}><path d="M12 21s-7-4.5-9.5-9A5.5 5.5 0 0 1 12 6a5.5 5.5 0 0 1 9.5 6c-2.5 4.5-9.5 9-9.5 9Z"/></svg>);
    case "data":
      return (<svg {...props}><rect x="3" y="13" width="4" height="8" rx="1"/><rect x="10" y="9" width="4" height="12" rx="1"/><rect x="17" y="5" width="4" height="16" rx="1"/></svg>);
    case "like":
      return (<svg {...props}><path d="M9 21H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h4v11Zm12-9.4-1.6 7a2 2 0 0 1-2 1.4H11V9.5l3.6-6a1.5 1.5 0 0 1 2.7 1.2L16 9h3.4A2 2 0 0 1 21 11.6Z"/></svg>);
    case "share":
      return (<svg {...props}><circle cx="6" cy="12" r="3"/><circle cx="18" cy="6" r="3"/><circle cx="18" cy="18" r="3"/><path d="m9 11 7-4M9 13l7 4" stroke="currentColor" strokeWidth="1.6" fill="none"/></svg>);
    case "briefcase":
      return (<svg {...props}><rect x="2" y="7" width="20" height="13" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2" fill="none" stroke="currentColor" strokeWidth="2"/></svg>);
    case "chart":
      return (<svg {...props}><path d="M3 3h2v18H3zM21 21H3v-2h18zM7 13l4-4 3 3 5-6 1 1-6 8-3-3-3 3-1-2Z"/></svg>);
    case "arrow-up":
      return (<svg {...props}><path d="m12 4 8 8-2 2-5-5v13h-2V9l-5 5-2-2 8-8Z"/></svg>);
    case "arrow-right":
      return (<svg {...props}><path d="m13 5 7 7-7 7-1.5-1.5L16 13H4v-2h12L11.5 6.5 13 5Z"/></svg>);
    case "people":
      return (<svg {...props}><circle cx="9" cy="8" r="3.5"/><circle cx="17" cy="9" r="2.5"/><path d="M2 20a7 7 0 0 1 14 0v1H2v-1Zm15 0a4.5 4.5 0 0 1 5-4.5V21h-5v-1Z"/></svg>);
    case "menu":
      return (<svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>);
    case "instagram":
      return (<svg {...props} fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor"/></svg>);
    case "whatsapp":
      return (<svg {...props}><path d="M12 3a9 9 0 0 0-7.7 13.6L3 21l4.5-1.2A9 9 0 1 0 12 3Zm5 12.4c-.2.6-1.2 1.2-1.7 1.3-.4.1-1 .1-1.6-.1a13 13 0 0 1-5-3.5 5.7 5.7 0 0 1-1.2-3c0-.5.2-1 .5-1.3l.4-.4c.1-.1.3-.1.4-.1h.4c.1 0 .3 0 .5.4l.7 1.6c0 .2 0 .3-.1.5l-.3.4c-.1.1-.2.2-.1.4.1.2.5.9 1.1 1.4.7.6 1.3.8 1.5.9.2.1.3.1.4 0l.7-.8c.1-.2.3-.2.5-.1l1.6.7c.2.1.3.2.3.3 0 0 .1.5 0 .9Z"/></svg>);
    case "linkedin":
      return (<svg {...props}><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="7.5" cy="8" r="1.4" fill="#0A0A0B"/><rect x="6.5" y="10" width="2" height="7.5" fill="#0A0A0B"/><path d="M11 10h2v1a2.5 2.5 0 0 1 4.5 1.5v5H15V13c0-.6-.4-1-1-1s-1 .4-1 1v4.5h-2V10Z" fill="#0A0A0B"/></svg>);
    case "x":
      return (<svg {...props}><path d="M17.5 3h3l-7 8 8 10h-6l-5-6.4L4.5 21h-3l7.4-8.4L1.5 3h6l4.5 5.8L17.5 3Z"/></svg>);
    default:
      return null;
  }
};

window.Icon = Icon;
